package com.simplilearn.services;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.entities.TransactionDetails;
import com.simplilearn.model.PaymentMode;
import com.simplilearn.model.PaymentRequest;
import com.simplilearn.model.PaymentResponse;
import com.simplilearn.repositories.TransactionDetailsRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PaymentServiceImpl implements PaymentService{
	@Autowired
	private TransactionDetailsRepository transactionDetailsRepository;
	
	@Override
	public long doPayment(PaymentRequest paymentRequest) {
		TransactionDetails transactionDetails=TransactionDetails.builder()
				.paymentDate(Instant.now())
				.paymentMode(paymentRequest.getPaymentMode().name())
				.paymentStatus("SUCCESS")
				.orderId(paymentRequest.getOrderId())
				.referenceNumber(paymentRequest.getReferenceNumber())
				.amount(paymentRequest.getAmount()).build();
		transactionDetailsRepository.save(transactionDetails);
		log.info("Transaction successfully completed with Id:{}",transactionDetails.getId());
		return transactionDetails.getId();
	}

	@Override
	public PaymentResponse getPaymentDetailsByOrderId(String orderId) {
		log.info("getting the payment details based on order Id:{}",orderId);
		TransactionDetails transactionDetails=
				transactionDetailsRepository.findByOrderId(Long.valueOf(orderId));
		PaymentResponse paymentResponse=PaymentResponse.builder()
				.paymentId(transactionDetails.getId())
				.paymentMode(PaymentMode.valueOf(transactionDetails.getPaymentMode()))
				.paymentDate(transactionDetails.getPaymentDate())
				.orderId(transactionDetails.getOrderId())
				.status(transactionDetails.getPaymentStatus())
				.amount(transactionDetails.getAmount())
				.build();
		return paymentResponse;
	}

}
