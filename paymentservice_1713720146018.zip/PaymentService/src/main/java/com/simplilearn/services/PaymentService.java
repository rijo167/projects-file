package com.simplilearn.services;

import com.simplilearn.model.PaymentRequest;
import com.simplilearn.model.PaymentResponse;

public interface PaymentService {
	long doPayment(PaymentRequest paymentRequest);
	PaymentResponse getPaymentDetailsByOrderId(String orderId);
}
