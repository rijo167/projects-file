// export const API_URL_RL ='http://localhost:9091';
// export const API_URL_Order ='http://localhost:9094';
// export const API_URL_FC ='http://localhost:9092';
// export const API_URL_UD ='http://localhost:9093';

export const K8ExternalIp = 'http://k8s-default-awsingre-3d4b7f90d4-122545836.eu-west-3.elb.amazonaws.com';

